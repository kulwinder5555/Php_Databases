<?php
var_dump($_SERVER["QUERY_STRING"]);
var_dump($_GET);
 ?>
